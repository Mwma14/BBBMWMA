# START OF FILE config.py

# Your bot's token from BotFather. This is the only mandatory value.
BOT_TOKEN = "8039934549:AAGOQ7HCCmNI2Ene5ubAPFrI-zBK1E9Rt_o"  # Replace with your bot's token

# The Telegram ID of the user who will be the first super-admin.
# The bot will automatically grant this user admin privileges on first run.
INITIAL_ADMIN_ID = 6158106622

# --- ADD THIS LINE ---
# Filename for the persistent scheduler database
SCHEDULER_DB_FILE = "scheduler.sqlite"
# END OF FILE config.py